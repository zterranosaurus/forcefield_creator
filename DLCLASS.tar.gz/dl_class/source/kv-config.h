#ifndef KV_CONFIG_H
#define KV_CONFIG_H

#define KV_REAL real(8)

#define KV_STDOUT_UNIT 6
#define KV_STDERR_UNIT 0

#define KV_FIRST_AVAILABLE_UNIT 77
#define KV_LAST_AVAILABLE_UNIT  88

#endif /* KV_CONFIG_H */

#ifndef KV_UTILS_H
#define KV_UTILS_H

/*
 *  'afailed' is provided by the 'kv_utils' module
 */

#ifndef KV_DISABLE_ASSERT
#  define kv_assert(stmt) if (.not.(stmt)) call afailed(__FILE__, __LINE__)
#  define kv_assert_not_reached() call afailed(__FILE__, __LINE__)
#  define KV_PURE_EXCEPT_ASSERT
#  define KV_USE_AFAILED use kv_utils, only : afailed
#else
#  define kv_assert(s)
#  define kv_assert_not_reached()
#  define KV_PURE_EXCEPT_ASSERT pure
#  define KV_USE_AFAILED
#endif /* KV_DISABLE_ASSERT */

#define KV_OUT_OF_MEMORY call out_of_memory(__FILE__, __LINE__)

#ifdef MPI
#  define KV_MASTER_ONLY_BEGIN if (sanderrank.eq.0) then
#  define KV_MASTER_ONLY_END end if
#else
#  define KV_MASTER_ONLY_BEGIN
#  define KV_MASTER_ONLY_END
#endif /* MPI */

#define KV_ERROR   ' ** KV-Error ** : '
#define KV_WARNING ' ** KV-Warning ** : '
#define KV_INFO    ' KV : '

#endif /* KV_UTILS_H */

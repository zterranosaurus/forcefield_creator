#!/bin/sh

rm -f HISTORY* OUTPUT STATIS REVCON* REVIVE fort.*

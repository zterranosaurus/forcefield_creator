#!/bin/sh

./clean.sh
../execute/DLPOLY.X

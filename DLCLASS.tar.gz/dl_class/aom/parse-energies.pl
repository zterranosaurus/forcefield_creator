#!/usr/bin/perl

use strict;

while (<STDIN>) {
    last if (/step\s+eng_tot\s+temp_tot\s+eng_cfg/);
}

while (<STDIN>) {
    if (/\-\-\-\-\-\-\-\-\-/) {
        $_ = <STDIN>;
        next if /\-\-\-\-\-\-\-\-\-/;
        print $_;
    }
}

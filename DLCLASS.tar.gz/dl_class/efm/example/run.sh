#!/bin/bash

export DO_ENG_FRC=1
exec ../../execute/DLPOLY.X
